<?php

class Admin extends Controller
{
    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        $this->views->render($this, "index");
    }
    public function login()
    {
        $get_data = json_decode(file_get_contents("php://input"));
        $username = $get_data->username;
        $password = $get_data->password;
        echo $username . " " . $password;
    }
}
