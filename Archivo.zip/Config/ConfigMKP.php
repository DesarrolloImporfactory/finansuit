<?php

const HOST = '158.220.107.176';
const USER = "imporsuit_marketplace";
const PASSWORD = "imporsuit_marketplace";
const DB = "imporsuit_marketplace";
const CHARSET = "utf8";
