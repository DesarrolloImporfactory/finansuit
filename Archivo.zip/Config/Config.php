<?php

const HOST = '127.0.0.1';
const USER = "root";
const PASSWORD = "";
const DB = "imporsuit_finanzas";
const CHARSET = "utf8";
